package com.example.cryptoclub1;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class CreateProfile extends AppCompatActivity {

    EditText etName,etBio,etProfession,etWeb,etEmail;
    Button cp_btn;
    ImageView imageView;
    ProgressBar progressBar;
    UsersMembers usersMembers;
    String currUserid;
    Uri image;
    UploadTask uploadTask;
    StorageReference storageReference;
    FirebaseDatabase firebaseDatabase =  FirebaseDatabase.getInstance();
    DatabaseReference databaseReference;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    DocumentReference documentReference;
    public static final int PICK_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_profile);

        usersMembers = new UsersMembers();

        imageView = findViewById(R.id.pic_prof);
        etName = findViewById(R.id.et_name);
        etBio = findViewById(R.id.et_bio);
        etProfession = findViewById(R.id.et_prof);
        etWeb = findViewById(R.id.et_website);
        etEmail = findViewById(R.id.et_email);

        progressBar = findViewById(R.id.prog_cp);
        cp_btn = findViewById(R.id.createProf_btn);

        FirebaseUser user= FirebaseAuth.getInstance().getCurrentUser();
        currUserid =  user.getUid();

        documentReference = db.collection("user").document(currUserid);
        storageReference = FirebaseStorage.getInstance().getReference("Profile Images");
        databaseReference = firebaseDatabase.getReference("All Users");

        cp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadData();//todo min 6:32 https://www.youtube.com/watch?v=BuW43bvYqIs&list=PL2dkge6Cz_wkhe4ygVRRPGIif5nEgnmDz&index=9&ab_channel=RajjanSharma
            }
        });
    }
}